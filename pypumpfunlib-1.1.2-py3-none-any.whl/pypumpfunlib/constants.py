from solders.pubkey import Pubkey
from solana.rpc.api import Client
import random


def load_rpc():
    rpc_endpoints_list = [
        {
            "name": "https://mainnet.helius-rpc.com/?api-key=0109717a-77b4-498a-bc3c-a0b31aa1b3bf"
        },
        {
            "name": "https://mainnet.helius-rpc.com/?api-key=f4713222-8bbc-4495-aace-5693e719712e"
        },
        {
            "name": "https://mainnet.helius-rpc.com/?api-key=efc82eb1-8237-4c46-b915-dee916dd3bd7"
        },
        {
            "name": "https://mainnet.helius-rpc.com/?api-key=26bec238-00c2-4961-ba13-faa7c0a2d767"
        },
        {
            "name": "https://mainnet.helius-rpc.com/?api-key=6dcb92e3-5222-4d11-9dc4-dbee6df8f373"
        },
        {
            "name": "https://mainnet.helius-rpc.com/?api-key=4cfa0f42-6b5c-48db-81f5-794c7d5f60eb"
        },
        {
            "name": "https://mainnet.helius-rpc.com/?api-key=15319bf4-5b40-4958-ac8d-6313aa55eb92"
        },
        {
            "name": "https://mainnet.helius-rpc.com/?api-key=e78cc375-92b4-42d9-a00f-d42c497da094"
        },
        {
            "name": "https://mainnet.helius-rpc.com/?api-key=3c97e454-1534-4fbf-86f0-7c581d56543d"
        },
        {
            "name": "https://mainnet.helius-rpc.com/?api-key=efa64d65-80ac-4f32-a701-fba4acc33236"
        },
        {
            "name": "https://mainnet.helius-rpc.com/?api-key=634713f0-b4f2-41dc-af7f-ed7d60bd70e2"
        }
    ]

    if rpc_endpoints_list:
        return random.choice(rpc_endpoints_list).get('name')
    else:
        return 'https://api.mainnet-beta.solana.com'


rpc_endpoints = load_rpc()
client = Client(rpc_endpoints)

GLOBAL = Pubkey.from_string("4wTV1YmiEkRvAtNtsSGPtUrqRYQMe5SKy2uB4Jjaxnjf")
FEE_RECIPIENT = Pubkey.from_string("CebN5WGQ4jvEPvsVU4EoHEpgzq1VV7AbicfhtW4xC9iM")
SYSTEM_PROGRAM = Pubkey.from_string("11111111111111111111111111111111")
TOKEN_PROGRAM = Pubkey.from_string("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA")
ASSOC_TOKEN_ACC_PROG = Pubkey.from_string("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL")
RENT = Pubkey.from_string("SysvarRent111111111111111111111111111111111")
EVENT_AUTHORITY = Pubkey.from_string("Ce6TQqeHC9p8KetsN6JsjHK7UTZk7nasjjnr7XxXp9F1")
PUMP_FUN_PROGRAM = Pubkey.from_string("6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P")

LAMPORTS_PER_SOL = 1_000_000_000
UNIT_PRICE = 1_000_000
UNIT_BUDGET = 100_000
