import struct
from solana.transaction import AccountMeta, Transaction
from spl.token.instructions import create_associated_token_account, get_associated_token_address, close_account, \
    CloseAccountParams
from solders.instruction import Instruction
from solders.compute_budget import set_compute_unit_limit, set_compute_unit_price
from pypumpfunlib.constants import *
from pypumpfunlib.core import check
from solana.rpc.types import TokenAccountOpts
from solana.rpc.types import TxOpts
from typing import Optional, Union
from solana.rpc.api import Keypair
from solders.pubkey import Pubkey
from construct import Padding, Struct, Int64ul, Flag
from solana.transaction import Signature
import requests
import time
import json


class PumpFunClient:
    def __init__(self, private_key):
        self.private_key = private_key
        self.load_keypair(self.private_key)

    @check
    def load_keypair(self, private_key):
        self.payer_keypair = Keypair.from_base58_string(private_key)

    def get_virtual_reserves(self, bonding_curve: Pubkey):
        bonding_curve_struct = Struct(
            Padding(8),
            "virtualTokenReserves" / Int64ul,
            "virtualSolReserves" / Int64ul,
            "realTokenReserves" / Int64ul,
            "realSolReserves" / Int64ul,
            "tokenTotalSupply" / Int64ul,
            "complete" / Flag
        )

        try:
            account_info = client.get_account_info(bonding_curve)
            data = account_info.value.data
            parsed_data = bonding_curve_struct.parse(data)
            return parsed_data
        except Exception:
            return None

    def derive_bonding_curve_accounts(self, mint_str: str):
        try:
            mint = Pubkey.from_string(mint_str)
            bonding_curve, _ = Pubkey.find_program_address(
                ["bonding-curve".encode(), bytes(mint)],
                PUMP_FUN_PROGRAM
            )
            associated_bonding_curve = get_associated_token_address(bonding_curve, mint)
            return bonding_curve, associated_bonding_curve
        except Exception:
            return None, None

    def get_coin_data(self, mint_str: str):
        bonding_curve, associated_bonding_curve = self.derive_bonding_curve_accounts(mint_str)
        if bonding_curve is None or associated_bonding_curve is None:
            return None

        virtual_reserves = self.get_virtual_reserves(bonding_curve)
        if virtual_reserves is None:
            return None

        try:
            virtual_token_reserves = int(virtual_reserves.virtualTokenReserves)
            virtual_sol_reserves = int(virtual_reserves.virtualSolReserves)
            token_total_supply = int(virtual_reserves.tokenTotalSupply)
            complete = bool(virtual_reserves.complete)

            return {
                "mint": mint_str,
                "bonding_curve": str(bonding_curve),
                "associated_bonding_curve": str(associated_bonding_curve),
                "virtual_token_reserves": virtual_token_reserves,
                "virtual_sol_reserves": virtual_sol_reserves,
                "token_total_supply": token_total_supply,
                "complete": complete
            }
        except Exception:
            return None

    def find_data(self, data, field):
        if isinstance(data, dict):
            if field in data:
                return data[field]
            else:
                for value in data.values():
                    result = self.find_data(value, field)
                    if result is not None:
                        return result
        elif isinstance(data, list):
            for item in data:
                result = self.find_data(item, field)
                if result is not None:
                    return result
        return None

    def get_token_balance(self, mint_str: str):
        try:
            pubkey_str = str(self.payer_keypair.pubkey())
            headers = {"accept": "application/json", "content-type": "application/json"}

            payload = {
                "id": 1,
                "jsonrpc": "2.0",
                "method": "getTokenAccountsByOwner",
                "params": [
                    pubkey_str,
                    {"mint": mint_str},
                    {"encoding": "jsonParsed"},
                ],
            }

            response = requests.post(rpc_endpoints, json=payload, headers=headers)
            ui_amount = self.find_data(response.json(), "uiAmount")
            return float(ui_amount)
        except Exception as e:
            return None

    def confirm_txn(self, txn_sig, max_retries=8, retry_interval=1.5):
        retries = 0
        if isinstance(txn_sig, str):
            txn_sig = Signature.from_string(txn_sig)
        while retries < max_retries:
            try:
                txn_res = client.get_transaction(txn_sig, encoding="json", commitment="confirmed",
                                                 max_supported_transaction_version=0)
                txn_json = json.loads(txn_res.value.transaction.meta.to_json())
                if txn_json['err'] is None:
                    print("[!] Transaction confirmed... try count:", retries + 1)
                    return True
                print("[!] Error: Transaction not confirmed. Retrying...")
                if txn_json['err']:
                    print("[!] Transaction failed.")
                    return False
            except Exception as e:
                print("[!] Awaiting confirmation... try count:", retries + 1)
                retries += 1
                time.sleep(retry_interval)
        print("[!] Max retries reached. Transaction confirmation failed.")
        return None

    def buy(self, mint_str: str, sol_in: float = 0.01, slippage: int = 25):
        try:
            coin_data = self.get_coin_data(mint_str)
            if not coin_data:
                print("[!] Failed to retrieve coin data...")
                return

            owner = self.payer_keypair.pubkey()
            mint = Pubkey.from_string(mint_str)
            token_account, token_account_instructions = None, None

            # Attempt to retrieve token account, otherwise create associated token account
            try:
                account_data = client.get_token_accounts_by_owner(owner, TokenAccountOpts(mint))
                token_account = account_data.value[0].pubkey
                token_account_instructions = None
            except:
                token_account = get_associated_token_address(owner, mint)
                token_account_instructions = create_associated_token_account(owner, owner, mint)

            # Calculate amount
            virtual_sol_reserves = coin_data['virtual_sol_reserves']
            virtual_token_reserves = coin_data['virtual_token_reserves']
            sol_in_lamports = sol_in * LAMPORTS_PER_SOL
            amount = int(sol_in_lamports * virtual_token_reserves / virtual_sol_reserves)

            # Calculate max_sol_cost
            slippage_adjustment = 1 + (slippage / 100)
            sol_in_with_slippage = sol_in * slippage_adjustment
            max_sol_cost = int(sol_in_with_slippage * LAMPORTS_PER_SOL)
            print("[-] Max Sol Cost:", sol_in_with_slippage)

            # Define account keys required for the swap
            MINT = Pubkey.from_string(coin_data['mint'])
            BONDING_CURVE = Pubkey.from_string(coin_data['bonding_curve'])
            ASSOCIATED_BONDING_CURVE = Pubkey.from_string(coin_data['associated_bonding_curve'])
            ASSOCIATED_USER = token_account
            USER = owner

            # Build account key list
            keys = [
                AccountMeta(pubkey=GLOBAL, is_signer=False, is_writable=False),
                AccountMeta(pubkey=FEE_RECIPIENT, is_signer=False, is_writable=True),
                AccountMeta(pubkey=MINT, is_signer=False, is_writable=False),
                AccountMeta(pubkey=BONDING_CURVE, is_signer=False, is_writable=True),
                AccountMeta(pubkey=ASSOCIATED_BONDING_CURVE, is_signer=False, is_writable=True),
                AccountMeta(pubkey=ASSOCIATED_USER, is_signer=False, is_writable=True),
                AccountMeta(pubkey=USER, is_signer=True, is_writable=True),
                AccountMeta(pubkey=SYSTEM_PROGRAM, is_signer=False, is_writable=False),
                AccountMeta(pubkey=TOKEN_PROGRAM, is_signer=False, is_writable=False),
                AccountMeta(pubkey=RENT, is_signer=False, is_writable=False),
                AccountMeta(pubkey=EVENT_AUTHORITY, is_signer=False, is_writable=False),
                AccountMeta(pubkey=PUMP_FUN_PROGRAM, is_signer=False, is_writable=False)
            ]

            # Construct the swap instruction
            data = bytearray()
            data.extend(bytes.fromhex("66063d1201daebea"))
            data.extend(struct.pack('<Q', amount))
            data.extend(struct.pack('<Q', max_sol_cost))
            data = bytes(data)
            swap_instruction = Instruction(PUMP_FUN_PROGRAM, data, keys)

            # Construct and sign transaction
            recent_blockhash = client.get_latest_blockhash().value.blockhash
            txn = Transaction(recent_blockhash=recent_blockhash, fee_payer=owner)
            txn.add(set_compute_unit_price(UNIT_PRICE))
            txn.add(set_compute_unit_limit(UNIT_BUDGET))
            if token_account_instructions:
                txn.add(token_account_instructions)
            txn.add(swap_instruction)
            txn.sign(self.payer_keypair)

            # Send and confirm transaction
            txn_sig = client.send_transaction(txn, self.payer_keypair, opts=TxOpts(skip_preflight=True)).value
            print("[-] Transaction Signature", txn_sig)
            confirm = self.confirm_txn(txn_sig)

        except Exception as e:
            print(e)

    def sell(self, mint_str: str, token_balance: Optional[Union[int, float]] = None, slippage: int = 25,
             close_token_account: bool = True):
        try:
            # Get coin data
            coin_data = self.get_coin_data(mint_str)
            if not coin_data:
                print("[!] Failed to retrieve coin data...")
                return

            owner = self.payer_keypair.pubkey()
            mint = Pubkey.from_string(mint_str)

            # Get token account
            token_account = get_associated_token_address(owner, mint)

            # Calculate token price
            sol_decimal = 10 ** 9
            token_decimal = 10 ** 6
            virtual_sol_reserves = coin_data['virtual_sol_reserves'] / sol_decimal
            virtual_token_reserves = coin_data['virtual_token_reserves'] / token_decimal
            token_price = virtual_sol_reserves / virtual_token_reserves
            print(f"[-] Token Price: {token_price:.20f} SOL")

            # Get token balance
            if token_balance == None:
                token_balance = self.get_token_balance(mint_str)
            print("[-] Token Balance:", token_balance)
            if token_balance == 0:
                return

            # Calculate amount
            amount = int(token_balance * token_decimal)

            # Calculate minimum SOL output
            sol_out = float(token_balance) * float(token_price)
            slippage_adjustment = 1 - (slippage / 100)
            sol_out_with_slippage = sol_out * slippage_adjustment
            min_sol_output = int(sol_out_with_slippage * LAMPORTS_PER_SOL)
            print("[-] Min Sol Output:", sol_out_with_slippage)

            # Define account keys required for the swap
            MINT = Pubkey.from_string(coin_data['mint'])
            BONDING_CURVE = Pubkey.from_string(coin_data['bonding_curve'])
            ASSOCIATED_BONDING_CURVE = Pubkey.from_string(coin_data['associated_bonding_curve'])
            ASSOCIATED_USER = token_account
            USER = owner

            # Build account key list
            keys = [
                AccountMeta(pubkey=GLOBAL, is_signer=False, is_writable=False),
                AccountMeta(pubkey=FEE_RECIPIENT, is_signer=False, is_writable=True),  # Writable
                AccountMeta(pubkey=MINT, is_signer=False, is_writable=False),
                AccountMeta(pubkey=BONDING_CURVE, is_signer=False, is_writable=True),  # Writable
                AccountMeta(pubkey=ASSOCIATED_BONDING_CURVE, is_signer=False, is_writable=True),  # Writable
                AccountMeta(pubkey=ASSOCIATED_USER, is_signer=False, is_writable=True),  # Writable
                AccountMeta(pubkey=USER, is_signer=True, is_writable=True),  # Writable Signer Fee Payer
                AccountMeta(pubkey=SYSTEM_PROGRAM, is_signer=False, is_writable=False),
                AccountMeta(pubkey=ASSOC_TOKEN_ACC_PROG, is_signer=False, is_writable=False),
                AccountMeta(pubkey=TOKEN_PROGRAM, is_signer=False, is_writable=False),
                AccountMeta(pubkey=EVENT_AUTHORITY, is_signer=False, is_writable=False),
                AccountMeta(pubkey=PUMP_FUN_PROGRAM, is_signer=False, is_writable=False)
            ]

            # Construct swap instruction
            data = bytearray()
            data.extend(bytes.fromhex("33e685a4017f83ad"))
            data.extend(struct.pack('<Q', amount))
            data.extend(struct.pack('<Q', min_sol_output))
            data = bytes(data)
            swap_instruction = Instruction(PUMP_FUN_PROGRAM, data, keys)

            # Construct and sign transaction
            recent_blockhash = client.get_latest_blockhash().value.blockhash
            txn = Transaction(recent_blockhash=recent_blockhash, fee_payer=owner)
            txn.add(set_compute_unit_price(UNIT_PRICE))
            txn.add(set_compute_unit_limit(UNIT_BUDGET))
            txn.add(swap_instruction)
            if close_token_account:
                close_account_instructions = close_account(
                    CloseAccountParams(TOKEN_PROGRAM, token_account, owner, owner))
                txn.add(close_account_instructions)
            txn.sign(self.payer_keypair)

            # Send and confirm transaction
            txn_sig = client.send_transaction(txn, self.payer_keypair, opts=TxOpts(skip_preflight=True)).value
            print("[-] Transaction Signature", txn_sig)
            confirm = self.confirm_txn(txn_sig)

        except Exception as e:
            print(e)
